## Office Werkstatt 1.3.2

### Yenilikler
- **Dosyalarım'da klasörler:** yeni klasör, iç içe klasörler, yol çubuğu, sürükle-bırak ve "Klasöre taşı…" ile taşıma, yeniden adlandırma, silme (içerik bir üst klasöre geçer).
- **Word / Excel / Slide:** üst çubukta diğer Werkzeug'lar gibi arama (Alt + M); motorun kendi komutlarını bulur ve çalıştırır. Word'ün kendi arama kutusu kaldırıldı (tek arama).

### Düzeltmeler
- Tek tema düğmesi: Excel ve Slide motorlarının kendi açık/koyu düğmesi kaldırıldı; Office Werkstatt'ın düğmesi motorları da değiştirir.
- Slide / Excel temaya artık doğru uyar (önceden ters dönebiliyordu).

## Office Werkstatt 1.3.1

### Düzeltmeler
- Word / Excel / Slide: üst çubuk artık diğer Werkzeug'larla aynı düzende (dil, tema ve kullanıcı sağda).

## Office Werkstatt 1.3.0

### Draw Werkzeug – not ve beyin fırtınası panosu
- Sonsuz tuval: not kartları (zengin metin), yapışkan notlar, metin, şekiller, öğelere yapışan bağlantılar, kalem/vurgulayıcı,
  çerçeveler, resimler ve **zihin haritası** (Tab = alt konu, Enter = sonraki konu).
- Klasik Office şeridi (Giriş · Ekle · Çiz · Görünüm · Yardım), seçimin üstünde mini biçim çubuğu.
- Şablonlar: beyin fırtınası, zihin haritası, kanban, retrospektif, SWOT, akış şeması. PNG / SVG / .excalidraw dışa aktarma.
- Eski çizimler ve `.excalidraw` dosyaları otomatik dönüştürülür.

### Word / Excel / Slide Werkzeug Pro
- **Farklı Kaydet** (Ctrl+Shift+S ve motorun kendi Farklı Kaydet / Dışa Aktar sayfaları) motorun yazabildiği **tüm biçimleri** listeler:
  - Word: DOCX, DOCM, DOTX, DOTM, DOC (RTF), ODT, OTT, FODT, RTF, Word XML, Word 2003 XML, PDF, HTML, Markdown, LaTeX, TXT, PNG
  - Excel: XLSX, XLSM, XLTX, XLTM, CSV, TSV, TXT, JSON, HTML, PDF
  - Slide: PPTX, PPTM, PPSX, PPSM, POTX, POTM, PDF, PNG, JPEG (çok slaytta ZIP), RTF / TXT ana hat, `.werkzeug`
- Slide'ın kendi biçimi artık **`.werkzeug`** adıyla görünür (eski adı `.deckcraft`).
- **Eski ve diğer biçimler açılır:** `.doc`, `.xls`, `.ppt` (PPT: slayt metinleri aktarılır), DOCM, DOTX, ODT, RTF, Markdown, XLSM, XLSB, ODS, CSV, PPSX, POTX …
- Belgeler motorların komut API'siyle açılır ve kaydedilir; Ctrl+S doğrudan kitaplığa kaydeder.
- Word / Excel / Slide, Office Werkstatt'ın **açık / koyu temasına** uyar.
- Word: “Geliştirici” sekmesi yerine **“Gelişmiş”**; Zotero / atıf araçları bu sekmenin altında.
- Yardım menüsünde **Güncellemeleri denetle** → GitHub Releases (tüm yerleşik Werkzeug'larda).

### Yeni araçlar
- **Design Werkzeug** – Canva tarzı tasarım stüdyosu (şablonlar, marka kiti, QR kod, stok medya, baskı PDF'i, video).
- **Formular Werkzeug** – sürükle-bırak form oluşturucu, yayınlama + QR kod, yanıtlar → Excel.

## Office Werkstatt 1.2.0

### Yazdırma ve kapatma (masaüstü)
- **Yazdırma artık çalışıyor ve önizleme var.** `window.print()` masaüstü uygulamasını tamamen donduruyordu (Windows 11 yazdırma
  penceresi açılmıyor, uygulama kapatılamıyordu). Artık Office Werkstatt'ın kendi **yazdırma önizlemesi** açılır: gerçek sayfalar,
  yazıcı, kopya, sayfa aralığı, yön, kâğıt boyutu, renk, *PDF olarak kaydet*. Word/Excel/Slide Pro ve PDF Werkstatt da bunu kullanır.
- **Kapatma:** Kaydedilmemiş bir PDF varken pencere sessizce açık kalıyordu; artık “Kaydedilmemiş değişiklikler – yine de kapat?” sorulur.
  Takılan bir sayfa veya yazdırma işi uygulamanın kapanmasını engellemez.
- Kapanışta görülen *“Cannot write headers after they are sent”* hatası giderildi.

### Güvenlik
- Sunucu varsayılan olarak yalnızca `127.0.0.1` adresinde dinler; ağda **giriş zorunlu** (aksi hâlde başlamaz). DNS-rebinding koruması.
- Belgelerdeki HTML (içe aktarma, `.owdoc`, paylaşılan sunucu) her gösterimde temizlenir — betik/olay işleyici çalışmaz.
- Kayıt hataları (401, 413, 500 …) artık fark edilir: değişiklikler korunur, yeniden denenir, kapatmadan önce uyarılır.
- Statik dosya yolları ayraç duyarlı ve gerçek yol üzerinden denetlenir.

### Düzenleyiciler
- **Word / Excel / Slide** doğrudan **Werkzeug Pro** motorunda açılır; ayrı “basit görünüm” ve Pro düğmesi kaldırıldı.
  Belgeler motorun kendi biçiminde (`.docx` / `.xlsx` / `.pptx`) kitaplıkta saklanır, içe aktarılan dosyalar kayıpsız korunur.
- **PDF Werkzeug:** çift menüler kaldırıldı (tek menü: PDF Werkstatt).
- **Note Werkzeug:** SilverBullet kaldırıldı; OneNote tarzı görünüme **takvim** eklendi (ay görünümü, yaklaşanlar,
  etkinlikten toplantı notu, `.ics` içe/dışa aktarma).
- **Draw Werkzeug:** Excalidraw düğmesi kaldırıldı.
- Dil değiştirirken ana sayfaya dönülmez; dil menüsündeki boşluklar kaldırıldı.
- `.xlsx` dışa aktarma tüm sayfaları ve stil bölümünü içerir.

## Office Werkstatt 1.1.1

### Düzeltmeler
- **PDF Werkzeug artık anında açılıyor.** PDF Werkstatt motoru 67 MB'lık tek bir HTML dosyasıydı; MuPDF, OCR dilleri ve 32 yazı tipi
  arayüzden *önce* yükleniyordu. Bu veriler ayrı dosyalara taşındı (`public/engines/pdf/fonts-extra.js`, `public/engines/pdf/assets/`)
  ve yalnızca gerektiğinde yükleniyor: sayfa 67 MB → 3,8 MB, menü ~1,4 sn yerine ~0,2 sn'de görünüyor.
- Açılan PDF, motor hazır olur olmaz aktarılıyor (sabit 400 ms bekleme ve yazı tiplerinin yüklenmesini bekleme kaldırıldı).
- Service worker, büyük motor dosyalarını her açılışta arka planda yeniden indirmiyor; eski 67 MB'lık önbellek siliniyor.
- `/api/health` doğru sürümü bildiriyor.
- `scripts/fetch-engines.js` PDF motorunu indirdikten sonra otomatik olarak böler (`scripts/split-pdf-engine.js`).

## Office Werkstatt 1.1.0

**Windows kurulum dosyası – internetsiz kurulur** (yönetici hakkı gerekmez, 5 dilli kurulum sihirbazı).

### Yenilikler
- Tam motorlar yerleşik: **Word / Excel / Slide Werkzeug Pro**, **SilverBullet** (Note), **Excalidraw** (Draw), **PDF Werkstatt** (kırmızı sürüm)
- Dil seçimi editör menülerini ve motorları da değiştirir (TR · DE · EN · ES · FR)
- Sunumlar `.pptx` olarak dışa aktarılabilir
- *Eigene App* Ayarlar'a taşındı
- *Diktieren* butonunun yanında “internet gerekir” uyarısı
- `.docx .xlsx .pptx .pdf .csv .md .excalidraw` için “Birlikte aç” kaydı

### Kurulum
`Office-Werkstatt-Setup-1.1.0.exe` dosyasını indirip çalıştırın. Belgeler `%APPDATA%\Office Werkstatt` içinde saklanır.
