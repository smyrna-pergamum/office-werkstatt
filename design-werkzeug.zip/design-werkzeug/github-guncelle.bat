@echo off
REM Office Werkstatt - Design Werkzeug'u GitHub'a gonderir. Bu klasorde (README.md, public, server, docs yaninda) calistirin. Gerekli: git
cd /d "%~dp0"
if exist ow-up rmdir /s /q ow-up
git clone --depth 1 https://github.com/smyrna-pergamum/office-werkstatt.git ow-up || goto :err
xcopy /E /Y /Q public ow-up\public\ >nul
xcopy /E /Y /Q server ow-up\server\ >nul
xcopy /E /Y /Q docs ow-up\docs\ >nul
copy /Y README.md ow-up\README.md >nul
cd ow-up
git add -A
git commit -m "Design Werkzeug: Canva-style design studio" || goto :err
git push origin main || goto :err
cd ..
rmdir /s /q ow-up
echo.
echo Tamam: GitHub guncellendi.
pause
exit /b 0
:err
echo.
echo Hata olustu - yukaridaki mesaja bakin.
pause
exit /b 1
